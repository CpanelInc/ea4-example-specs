=======
CREDITS
=======

The mod_wsgi source code incorporates C functions for calculating memory
usage from: 

:Author:  David Robert Nadeau
:Site:    http://NadeauSoftware.com/
:License: Creative Commons Attribution 3.0 Unported License
          http://creativecommons.org/licenses/by/3.0/deed.en_US
